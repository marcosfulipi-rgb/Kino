# EasyBiz Online - Criação de Sites Profissionais

Site comercial completo e de alta conversão desenvolvido em React 19 + TypeScript + Vite + Tailwind CSS v4.

## 🚀 Como Hospedar na Netlify

### Opção 1: Arrastar e Soltar (Drag & Drop)
1. No seu computador, descompacte o arquivo ZIP.
2. Execute no terminal:
   ```bash
   npm install
   npm run build
   ```
3. Acesse [app.netlify.com](https://app.netlify.com/).
4. Na aba **Sites**, arraste a pasta `dist` gerada para a área de upload do Netlify.
5. Seu site estará no ar em poucos segundos com HTTPS gratuito!

### Opção 2: Conectar com GitHub / Repositório Git
1. Suba os arquivos deste projeto para o seu GitHub.
2. No Netlify, clique em **Add new site** > **Import an existing project** > **GitHub**.
3. Selecione o repositório. O arquivo `netlify.toml` já configurado definirá automaticamente:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
4. Clique em **Deploy site**.

---

## 💜 Como Usar no Lovable

1. Acesse [lovable.dev](https://lovable.dev/).
2. Crie um novo projeto ou importe este repositório via GitHub ou upload dos arquivos fonte.
3. A estrutura padrão Vite + React + Tailwind é 100% compatível.

---

## 💻 Executar Localmente

```bash
# Instalar dependências
npm install

# Iniciar servidor de desenvolvimento (porta 3000 ou 5173)
npm run dev

# Gerar build de produção
npm run build
```

---

## 📞 Informações de Contato Configuradas

- **WhatsApp**: (41) 99858-2431
- **E-mail**: Marcos.fulipi@gmail.com
- **Localização**: Curitiba - PR · Atendimento Nacional
