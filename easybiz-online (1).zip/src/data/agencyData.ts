import { AgencyService, WebPackage, CommercialContactInfo } from '../types';

export const COMMERCIAL_INFO: CommercialContactInfo = {
  phone: '(41) 99858-2431',
  whatsappDisplay: '(41) 99858-2431',
  whatsappNumber: '5541998582431',
  email: 'Marcos.fulipi@gmail.com',
  address: 'Curitiba',
  city: 'Curitiba',
  state: 'PR',
  businessHours: 'Segunda a Sexta das 08h30 às 18h30 | Atendimento Online 24h'
};

export const createWhatsAppUrl = (customMessage?: string) => {
  const defaultText = 'Olá! Gostaria de saber mais sobre a criação de sites profissionais para a minha empresa.';
  const encodedText = encodeURIComponent(customMessage || defaultText);
  return `https://wa.me/${COMMERCIAL_INFO.whatsappNumber}?text=${encodedText}`;
};

export const AGENCY_SERVICES: AgencyService[] = [
  {
    id: 'institucional',
    title: '1. Criação de Sites Institucionais',
    shortDescription: 'Apresente a história, valores, equipe e diferenciais da sua empresa com máxima autoridade e credibilidade.',
    fullDescription: 'Desenvolvido para empresas consolidadas ou novos negócios que desejam transmitir confiança imediata, com design moderno, páginas de apresentação institucional e integração direta com WhatsApp.',
    iconName: 'Building2',
    idealFor: 'Empresas corporativas, escritórios, consultorias e indústrias',
    features: ['Página Sobre Nós institucional', 'Apresentação de diferenciais', 'Localização e mapa interativo', 'Design responsivo para celular e computador'],
    sampleMockupImage: '/src/assets/images/agency_portfolio_showcase_1793637391253.jpg'
  },
  {
    id: 'comercial',
    title: '2. Sites Comerciais',
    shortDescription: 'Estrutura voltada para conversão de visitantes em clientes pagantes com chamadas estratégicas para ação.',
    fullDescription: 'Projetado com foco em atrair novos clientes, destacar produtos ou serviços mais lucrativos e gerar pedidos de proposta a todo momento.',
    iconName: 'TrendingUp',
    idealFor: 'Comércios locais, distribuidoras e empresas B2B',
    features: ['Botões de contato em destaque', 'Formulário de solicitação de proposta', 'Carrossel de produtos principais', 'Layout americano de alto impacto'],
    sampleMockupImage: '/src/assets/images/hero_web_agency_curitiba_1793637391050.jpg'
  },
  {
    id: 'lojas',
    title: '3. Sites para Lojas e Pequenos Negócios',
    shortDescription: 'Exiba seus produtos, fotos, novidades e localização para clientes da sua cidade comprarem de você.',
    fullDescription: 'Perfeito para o lojista de bairro ou centro comercial que quer ser encontrado no Google por clientes de Curitiba e região procurando o que ele vende.',
    iconName: 'ShoppingBag',
    idealFor: 'Lojas de roupas, calçados, autopeças, papelarias e varejo em geral',
    features: ['Vitrine de produtos em destaque', 'Integração de pedidos direto no WhatsApp', 'Horários de funcionamento', 'Mapa de como chegar'],
    sampleMockupImage: '/src/assets/images/agency_portfolio_showcase_1793637391253.jpg'
  },
  {
    id: 'servicos',
    title: '4. Sites para Prestadores de Serviços',
    shortDescription: 'Receba solicitações de orçamento diárias para o seu trabalho direto no seu celular.',
    fullDescription: 'Ideal para profissionais autônomos e empresas de serviços que querem parar de depender apenas de indicações e começar a atrair clientes qualificados pela internet.',
    iconName: 'Briefcase',
    idealFor: 'Eletricistas, pintores, marceneiros, contadores, advogados e técnicos',
    features: ['Calculadora ou formulário de orçamento', 'Área de atuação e cidades atendidas', 'Galeria de fotos de trabalhos realizados', 'Botão flutuante de WhatsApp'],
    sampleMockupImage: '/src/assets/images/hero_web_agency_curitiba_1793637391050.jpg'
  },
  {
    id: 'restaurantes',
    title: '5. Sites para Restaurantes e Lanchonetes',
    shortDescription: 'Cardápio digital atraente, horários de atendimento, pedidos online e reservas de mesa.',
    fullDescription: 'Apresente suas especialidades com fotos de dar água na boca. Facilite o acesso dos clientes ao cardápio e receba pedidos no WhatsApp sem taxas abusivas de aplicativos.',
    iconName: 'Utensils',
    idealFor: 'Restaurantes, pizzarias, hamburguerias, cafeterias e buffets',
    features: ['Cardápio digital interativo', 'Fotos profissionais dos pratos', 'Botão "Fazer Pedido no WhatsApp"', 'Horários de atendimento e endereço'],
    sampleMockupImage: '/src/assets/images/agency_portfolio_showcase_1793637391253.jpg'
  },
  {
    id: 'beleza',
    title: '6. Sites para Salões de Beleza e Barbearias',
    shortDescription: 'Apresentação de serviços de estética, tabela de preços e facilidade de agendamento online.',
    fullDescription: 'Destaque o trabalho dos seus profissionais, tratamentos capilares, estética e cortes masculinos com um visual sofisticado que atrai clientes que valorizam qualidade.',
    iconName: 'Scissors',
    idealFor: 'Salões femininos, barbearias premium, clínicas de estética e esmalterias',
    features: ['Tabela visual de serviços e valores', 'Galeria de fotos dos cortes e penteados', 'Botão de agendamento direto', 'Perfis dos profissionais'],
    sampleMockupImage: '/src/assets/images/hero_web_agency_curitiba_1793637391050.jpg'
  },
  {
    id: 'manutencao',
    title: '7. Sites para Limpeza, Construção e Manutenção',
    shortDescription: 'Transmita segurança, profissionalismo e garantia para clientes residenciais e corporativos.',
    fullDescription: 'Projetos sob medida para prestadores de serviços pesados e reformas que precisam demonstrar idoneidade, certificados, alvarás e receber pedidos de visita técnica com rapidez.',
    iconName: 'HardHat',
    idealFor: 'Empresas de reformas, construtoras, conservação predial e instalações',
    features: ['Formulário com metragem do imóvel', 'Apresentação de equipe licenciada', 'Lista de cidades e bairros atendidos', 'Chamada para visita técnica'],
    sampleMockupImage: '/src/assets/images/hero_web_agency_curitiba_1793637391050.jpg'
  },
  {
    id: 'personalizados',
    title: '8. Sites Personalizados para Diferentes Segmentos',
    shortDescription: 'Projetos exclusivos desenvolvidos com base nas necessidades específicas do seu modelo de negócio.',
    fullDescription: 'Se o seu segmento tem processos únicos, nós criamos uma estrutura sob medida com os elementos visuais, textos e fluxos de atendimento adequados ao seu público.',
    iconName: 'Sparkles',
    idealFor: 'Clínicas médicas, academias, escolas, imobiliárias e nichos específicos',
    features: ['Estrutura 100% personalizada', 'Integrações específicas', 'Copywriting persuasivo dedicado', 'Treinamento de uso'],
    sampleMockupImage: '/src/assets/images/agency_portfolio_showcase_1793637391253.jpg'
  }
];

export const AGENCY_PACKAGES: WebPackage[] = [
  {
    id: 'essencial',
    name: 'Site Essencial',
    priceBRL: 300,
    tagline: 'O ponto de partida perfeito para colocar sua empresa na internet com elegância e baixo custo.',
    targetAudience: 'Para profissionais autônomos, prestadores de serviços e pequenos comércios que precisam de presença digital rápida.',
    deliveryTime: 'Entrega rápida em até 3 a 5 dias úteis',
    features: [
      'Site institucional de página única (One-page moderna)',
      'Design responsivo (perfeito em celular e computador)',
      'Botão flutuante de contato no WhatsApp',
      'Apresentação clara dos seus produtos ou serviços',
      'Formulário simples de contato e orçamento',
      'Configuração inicial e entrega pronto para publicação',
      'Hospedagem rápida e segura'
    ],
    limits: {
      pages: '1 Página estruturada em seções completas',
      whatsappButton: true,
      googleMaps: true,
      domainSetup: true,
      contactForm: true,
      catalogOrMenu: false,
      seoOptimization: true,
      mobileOptimized: true
    }
  },
  {
    id: 'profissional',
    name: 'Site Profissional',
    priceBRL: 450,
    highlighted: true,
    badge: 'Mais Escolhido por Empresários',
    tagline: 'A solução ideal para empresas que desejam atrair novos clientes e fortalecer sua marca.',
    targetAudience: 'Para empresas comerciais, lojas físicas, consultórios e prestadores que querem destaque na concorrência.',
    deliveryTime: 'Entrega em até 5 a 7 dias úteis',
    features: [
      'Estrutura expandida em múltiplas seções estratégicas',
      'Galeria visual de produtos, serviços e projetos realizados',
      'Integração oficial com Google Maps para busca local',
      'Botão inteligente de WhatsApp com mensagem personalizada',
      'Formulário detalhado de solicitação de orçamento',
      'Otimização para mecanismos de busca (SEO Local Curitiba e Região)',
      'Design americano sofisticado em azul e branco',
      'Suporte humanizado para tirar todas as suas dúvidas'
    ],
    limits: {
      pages: 'Até 4 páginas / seções temáticas de alto impacto',
      whatsappButton: true,
      googleMaps: true,
      domainSetup: true,
      contactForm: true,
      catalogOrMenu: true,
      seoOptimization: true,
      mobileOptimized: true
    }
  },
  {
    id: 'premium',
    name: 'Site Premium',
    priceBRL: 600,
    tagline: 'O pacote completo de autoridade máxima com recursos avançados para empresas de alto padrão.',
    targetAudience: 'Para negócios consolidados, restaurantes com cardápio dinâmico, salões ou clínicas que exigem excelência visual.',
    deliveryTime: 'Entrega personalizada em até 7 a 10 dias úteis',
    features: [
      'Estrutura corporativa completa com identidade personalizada',
      'Cardápio digital, catálogo dinâmico ou agendamento online',
      'Copywriting persuasivo que valoriza os diferenciais da sua empresa',
      'Otimização avançada de velocidade e carregamento instantâneo',
      'Integração com WhatsApp, E-mail profissional e Redes Sociais',
      'Banner interativo de apresentação e chamadas estratégicas',
      'Treinamento simples para você gerenciar o conteúdo com facilidade',
      'Atendimento prioritário da nossa equipe de criação'
    ],
    limits: {
      pages: 'Estrutura completa personalizada sem limites de seções',
      whatsappButton: true,
      googleMaps: true,
      domainSetup: true,
      contactForm: true,
      catalogOrMenu: true,
      seoOptimization: true,
      mobileOptimized: true
    }
  }
];

export const WHY_HAVE_A_WEBSITE = [
  {
    id: 'disponibilidade',
    title: 'Sua empresa disponível na internet',
    description: 'Enquanto você descansa, seu site continua aberto 24 horas por dia, 7 dias por semana, apresentando seu negócio para potenciais clientes.',
    iconName: 'Clock'
  },
  {
    id: 'credibilidade',
    title: 'Mais credibilidade profissional',
    description: 'Hoje em dia, antes de fechar um serviço ou compra, o cliente pesquisa no Google. Ter um site profissional transmite segurança, autoridade e seriedade imediata.',
    iconName: 'ShieldCheck'
  },
  {
    id: 'apresentacao',
    title: 'Apresentação dos seus produtos e serviços',
    description: 'Mostre fotos reais, descrições claras, vantagens exclusivas e diferenciais da sua empresa de maneira organizada e elegante.',
    iconName: 'Layout'
  },
  {
    id: 'facilidade',
    title: 'Facilidade para seus clientes encontrarem sua empresa',
    description: 'Clientes de Curitiba, Paraná e qualquer outra região encontram seu endereço, telefone, mapa de como chegar e horários de atendimento em segundos.',
    iconName: 'MapPin'
  },
  {
    id: 'contato',
    title: 'Canal de contato direto com seus clientes',
    description: 'Reduza a perda de vendas com botões diretos para o WhatsApp, formulários de orçamento rápidos e chamadas para ligação a apenas um toque na tela.',
    iconName: 'PhoneCall'
  }
];

export const HOW_IT_WORKS_STEPS = [
  {
    stepNumber: '01',
    title: 'Você entra em contato conosco',
    description: 'Fale conosco pelo WhatsApp ou preencha o formulário informando o ramo da sua empresa e o pacote desejado.'
  },
  {
    stepNumber: '02',
    title: 'Conversamos sobre sua empresa',
    description: 'Entendemos quais produtos ou serviços você oferece, seu público-alvo e o objetivo comercial do seu novo site.'
  },
  {
    stepNumber: '03',
    title: 'Desenvolvemos seu site personalizado',
    description: 'Nossa equipe cria um design moderno, rápido, com textos claros e adaptado perfeitamente para celulares e computadores.'
  },
  {
    stepNumber: '04',
    title: 'Você aprova o projeto',
    description: 'Apresentamos o site pronto para você navegar, testar os botões e solicitar os ajustes necessários até ficar 100% satisfeito.'
  },
  {
    stepNumber: '05',
    title: 'Entregamos seu site pronto para publicação',
    description: 'Colocamos seu site no ar na internet. Sua empresa passa a ter endereço profissional próprio e pronta para atrair clientes!'
  }
];
