import { QuoteInquiry } from '../types';

const STORAGE_KEY = 'easybiz_agency_inquiries';

export const getQuoteInquiries = (): QuoteInquiry[] => {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Error loading quote inquiries:', err);
    return [];
  }
};

export const saveQuoteInquiry = (inquiry: Partial<QuoteInquiry>): QuoteInquiry => {
  const all = getQuoteInquiries();
  const newInquiry: QuoteInquiry = {
    id: `inq_${Date.now()}`,
    status: 'novo',
    createdAt: new Date().toISOString(),
    ...inquiry,
  };
  all.unshift(newInquiry);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
  } catch (err) {
    console.error('Error saving quote inquiry:', err);
  }
  return newInquiry;
};

export const formatCurrencyBRL = (amount: number): string => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2
  }).format(amount);
};

// Aliases for convenience across components
export const saveInquiry = saveQuoteInquiry;
export const formatBRL = formatCurrencyBRL;
