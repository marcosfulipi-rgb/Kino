import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Default environment variable lookup or custom stored configuration
const getEnvOrStoredKey = (envKey: string, storageKey: string): string => {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem(storageKey);
    if (stored) return stored;
  }
  return (import.meta.env[envKey] as string) || '';
};

export const getSupabaseConfig = () => {
  const url = getEnvOrStoredKey('VITE_SUPABASE_URL', 'easybiz_custom_supabase_url');
  const anonKey = getEnvOrStoredKey('VITE_SUPABASE_ANON_KEY', 'easybiz_custom_supabase_anon_key');
  return {
    url,
    anonKey,
    isConfigured: Boolean(url && anonKey && url.startsWith('http'))
  };
};

let supabaseInstance: SupabaseClient | null = null;

export const getSupabaseClient = (): SupabaseClient | null => {
  const { url, anonKey, isConfigured } = getSupabaseConfig();
  if (!isConfigured) {
    return null;
  }
  if (!supabaseInstance) {
    try {
      supabaseInstance = createClient(url, anonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true
        }
      });
    } catch (err) {
      console.warn('Failed to initialize Supabase client:', err);
      return null;
    }
  }
  return supabaseInstance;
};

export const saveCustomSupabaseConfig = (url: string, anonKey: string) => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('easybiz_custom_supabase_url', url.trim());
    localStorage.setItem('easybiz_custom_supabase_anon_key', anonKey.trim());
    supabaseInstance = null; // reset instance
  }
};

export const clearCustomSupabaseConfig = () => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('easybiz_custom_supabase_url');
    localStorage.removeItem('easybiz_custom_supabase_anon_key');
    supabaseInstance = null;
  }
};

/**
 * Complete production-ready Supabase SQL Migration
 * Can be run directly inside the Supabase SQL Editor
 */
export const SUPABASE_SQL_SCHEMA = `-- ==========================================
-- EasyBiz Online - Supabase Production Schema
-- Tables: profiles, businesses, inquiries, quotes, appointments, subscriptions
-- ==========================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. User Profiles Table (Linked to auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  business_name TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Business Sites Table
CREATE TABLE IF NOT EXISTS public.businesses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL, -- cleaning, landscaping, construction, beauty, plumbing, restaurants
  tagline TEXT,
  description TEXT,
  owner_name TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  zip TEXT,
  hero_image TEXT,
  services JSONB DEFAULT '[]'::jsonb,
  operating_hours JSONB DEFAULT '{}'::jsonb,
  theme JSONB DEFAULT '{"accentColor":"#2563EB","fontStyle":"modern","heroLayout":"split"}'::jsonb,
  published BOOLEAN DEFAULT true,
  views_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Customer Contact Inquiries
CREATE TABLE IF NOT EXISTS public.inquiries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT,
  service_requested TEXT,
  message TEXT NOT NULL,
  status TEXT DEFAULT 'new', -- new, contacted, resolved, archived
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Quote Requests
CREATE TABLE IF NOT EXISTS public.quotes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT,
  service_type TEXT NOT NULL,
  project_scope TEXT NOT NULL,
  timeline TEXT NOT NULL,
  estimated_budget TEXT,
  status TEXT DEFAULT 'pending', -- pending, reviewed, quoted, accepted, declined
  provided_quote_amount NUMERIC(10, 2),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Appointment Bookings
CREATE TABLE IF NOT EXISTS public.appointments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT,
  service_name TEXT NOT NULL,
  appointment_date DATE NOT NULL,
  time_slot TEXT NOT NULL,
  status TEXT DEFAULT 'confirmed', -- confirmed, pending, completed, cancelled
  address TEXT,
  special_instructions TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Subscriptions (Stripe billing state)
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  tier TEXT NOT NULL DEFAULT 'starter', -- starter ($9.90), professional ($19.90), business ($39.90)
  status TEXT NOT NULL DEFAULT 'active',
  monthly_price NUMERIC(6, 2) NOT NULL,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  card_last4 TEXT,
  current_period_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security (RLS) Configuration
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

-- Public can view published businesses
CREATE POLICY "Public businesses can be viewed by anyone" 
  ON public.businesses FOR SELECT 
  USING (published = true);

-- Public can submit inquiries, quotes, and appointments to published businesses
CREATE POLICY "Anyone can submit inquiry to published business"
  ON public.inquiries FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can submit quote request to published business"
  ON public.quotes FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can book appointment with published business"
  ON public.appointments FOR INSERT
  WITH CHECK (true);
`;
