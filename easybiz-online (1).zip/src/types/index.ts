export type AgencyServiceCategory = 
  | 'institucional'
  | 'comercial'
  | 'lojas'
  | 'servicos'
  | 'restaurantes'
  | 'beleza'
  | 'manutencao'
  | 'personalizados';

export interface AgencyService {
  id: AgencyServiceCategory;
  title: string;
  shortDescription: string;
  fullDescription: string;
  iconName: string;
  idealFor: string;
  features: string[];
  sampleMockupImage?: string;
}

export type WebPackageTier = 'essencial' | 'profissional' | 'premium';

export interface WebPackage {
  id: WebPackageTier;
  name: string;
  priceBRL: number;
  highlighted?: boolean;
  badge?: string;
  tagline: string;
  targetAudience: string;
  deliveryTime: string;
  features: string[];
  limits: {
    pages: string;
    whatsappButton: boolean;
    googleMaps: boolean;
    domainSetup: boolean;
    contactForm: boolean;
    catalogOrMenu: boolean;
    seoOptimization: boolean;
    mobileOptimized: boolean;
  };
}

export interface QuoteInquiry {
  id: string;
  clientName?: string;
  name?: string;
  companyName?: string;
  whatsapp?: string;
  email?: string;
  segment?: string;
  serviceCategory?: string;
  selectedPackage?: string;
  packageTier?: string;
  city?: string;
  state?: string;
  projectDetails?: string;
  notes?: string;
  status: 'novo' | 'em_atendimento' | 'proposta_enviada' | 'fechado';
  createdAt: string;
}

export interface CommercialContactInfo {
  phone: string;
  whatsappDisplay: string;
  whatsappNumber: string; // E.164 without plus e.g. 5541998421200
  email: string;
  address: string;
  city: string;
  state: string;
  businessHours: string;
}
