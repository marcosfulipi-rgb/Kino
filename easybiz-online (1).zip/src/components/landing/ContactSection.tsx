import React, { useState } from 'react';
import { COMMERCIAL_INFO, AGENCY_PACKAGES, AGENCY_SERVICES, createWhatsAppUrl } from '../../data/agencyData';
import { saveInquiry } from '../../services/agencyStorage';
import { 
  Phone, Mail, MapPin, Clock, MessageCircle, 
  Send, CheckCircle2, ArrowRight, ShieldCheck, HelpCircle 
} from 'lucide-react';

interface ContactSectionProps {
  initialPackageId?: string;
  initialServiceId?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  initialPackageId,
  initialServiceId
}) => {
  const [formData, setFormData] = useState({
    name: '',
    companyName: '',
    whatsapp: '',
    city: 'Curitiba',
    state: 'PR',
    serviceCategory: initialServiceId || 'institucional',
    packageTier: initialPackageId || 'profissional',
    notes: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.whatsapp) return;

    setLoading(true);
    setTimeout(() => {
      saveInquiry({
        name: formData.name,
        companyName: formData.companyName,
        whatsapp: formData.whatsapp,
        city: formData.city,
        state: formData.state,
        serviceCategory: formData.serviceCategory,
        packageTier: formData.packageTier,
        notes: formData.notes
      });
      setLoading(false);
      setSubmitted(true);
    }, 400);
  };

  const getWhatsAppDirectMsg = () => {
    const pkgName = AGENCY_PACKAGES.find(p => p.id === formData.packageTier)?.name || 'Criação de Sites';
    const srvName = AGENCY_SERVICES.find(s => s.id === formData.serviceCategory)?.title || 'Geral';
    return `Olá! Meu nome é ${formData.name || 'Empresário'} da empresa ${formData.companyName || '(a definir)'} de ${formData.city || 'Curitiba'}/${formData.state || 'PR'}. Gostaria de solicitar um orçamento para o *${pkgName}* no segmento *${srvName}*.`;
  };

  return (
    <section id="contato" className="py-20 sm:py-28 bg-slate-950 text-white relative border-t border-slate-800">
      
      {/* Background radial highlight */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_50%_100%,rgba(37,99,235,0.15),transparent_70%)]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-950 border border-blue-800 text-blue-400 text-xs font-semibold uppercase tracking-wider">
            <span>Fale com Nossos Especialistas</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display text-balance">
            Entre em Contato e Solicite seu Orçamento
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Tire suas dúvidas ou envie as informações da sua empresa. Retornamos com agilidade para apresentar a melhor solução para você.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Commercial Information & WhatsApp Channel */}
          <div className="lg:col-span-5 space-y-8">
            
            <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-8 space-y-6 shadow-xl">
              <h3 className="text-xl font-bold text-white font-display">
                Informações Comerciais
              </h3>
              
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Nossa equipe atende empresas de Curitiba, Região Metropolitana e de todas as cidades do Brasil com suporte 100% digital e atendimento personalizado.
              </p>

              <div className="space-y-4 pt-2">
                {/* WhatsApp */}
                <a
                  href={createWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 hover:bg-emerald-900/40 transition-colors flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-sm">
                      <MessageCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 block">
                        Atendimento Imediato via WhatsApp
                      </span>
                      <span className="text-sm font-extrabold text-white">
                        {COMMERCIAL_INFO.whatsappDisplay}
                      </span>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 transition-transform" />
                </a>

                {/* Telefone */}
                <a
                  href={`tel:${COMMERCIAL_INFO.whatsappNumber}`}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 hover:border-blue-500/50 hover:bg-slate-900/50 transition-colors flex items-center gap-3.5 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                      Telefone Comercial
                    </span>
                    <span className="text-sm font-semibold text-white group-hover:text-blue-300 transition-colors">
                      {COMMERCIAL_INFO.phone}
                    </span>
                  </div>
                </a>

                {/* Email */}
                <a
                  href={`mailto:${COMMERCIAL_INFO.email}`}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 hover:border-blue-500/50 hover:bg-slate-900/50 transition-colors flex items-center gap-3.5 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div className="overflow-hidden">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                      E-mail para Contato
                    </span>
                    <span className="text-sm font-semibold text-white group-hover:text-blue-300 transition-colors truncate block">
                      {COMMERCIAL_INFO.email}
                    </span>
                  </div>
                </a>

                {/* Localização */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                      Localização
                    </span>
                    <span className="text-sm font-semibold text-white">
                      {COMMERCIAL_INFO.address}
                    </span>
                    <span className="text-xs text-slate-400 block">
                      {COMMERCIAL_INFO.city} - {COMMERCIAL_INFO.state} · Atendimento Nacional
                    </span>
                  </div>
                </div>

                {/* Horários */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                      Horário de Atendimento
                    </span>
                    <span className="text-xs font-semibold text-slate-300">
                      {COMMERCIAL_INFO.businessHours}
                    </span>
                  </div>
                </div>
              </div>

              {/* Direct WhatsApp Big Button */}
              <div className="pt-2">
                <a
                  href={createWhatsAppUrl('Olá! Gostaria de conversar com um especialista sobre a criação de um site para minha empresa.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-900/30 transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>FALAR PELO WHATSAPP AGORA</span>
                </a>
              </div>
            </div>

          </div>

          {/* Right Column: Quote Request Form */}
          <div className="lg:col-span-7">
            <div className="bg-slate-900/90 rounded-3xl border border-slate-800 p-6 sm:p-10 shadow-2xl relative">
              
              {submitted ? (
                <div className="py-12 text-center space-y-6">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold text-white font-display">
                      Solicitação Recebida com Sucesso!
                    </h3>
                    <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                      Obrigado, <strong className="text-white">{formData.name}</strong>. Nossa equipe comercial já recebeu os detalhes da sua empresa e entrará em contato em breve via WhatsApp.
                    </p>
                  </div>

                  <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={createWhatsAppUrl(getWhatsAppDirectMsg())}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>AGILIZAR PELO WHATSAPP</span>
                    </a>

                    <button
                      type="button"
                      onClick={() => setSubmitted(false)}
                      className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Enviar Outra Solicitação
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="border-b border-slate-800 pb-4">
                    <h3 className="text-2xl font-extrabold text-white font-display">
                      Formulário de Orçamento
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Preencha os campos abaixo para receber uma proposta personalizada para a sua empresa.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Nome */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        Seu Nome *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ex: Carlos Eduardo"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      />
                    </div>

                    {/* Nome da Empresa */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        Nome da Empresa ou Negócio
                      </label>
                      <input
                        type="text"
                        value={formData.companyName}
                        onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                        placeholder="Ex: Marmoraria Curitiba"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* WhatsApp */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        WhatsApp com DDD *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.whatsapp}
                        onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                        placeholder="(41) 99999-9999"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      />
                    </div>

                    {/* Cidade e Estado */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        Cidade e Estado
                      </label>
                      <input
                        type="text"
                        value={`${formData.city} - ${formData.state}`}
                        onChange={(e) => {
                          const parts = e.target.value.split('-');
                          setFormData({ 
                            ...formData, 
                            city: parts[0]?.trim() || '', 
                            state: parts[1]?.trim() || '' 
                          });
                        }}
                        placeholder="Curitiba - PR"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Segmento */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        Segmento de Atuação
                      </label>
                      <select
                        value={formData.serviceCategory}
                        onChange={(e) => setFormData({ ...formData, serviceCategory: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      >
                        {AGENCY_SERVICES.map(s => (
                          <option key={s.id} value={s.id}>
                            {s.title}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Pacote */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300">
                        Pacote Desejado
                      </label>
                      <select
                        value={formData.packageTier}
                        onChange={(e) => setFormData({ ...formData, packageTier: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      >
                        {AGENCY_PACKAGES.map(p => (
                          <option key={p.id} value={p.id}>
                            {p.name} — R$ {p.priceBRL},00
                          </option>
                        ))}
                        <option value="duvida">Ainda estou em dúvida (Preciso de orientação)</option>
                      </select>
                    </div>
                  </div>

                  {/* Mensagem / Observações */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Detalhes sobre o que você precisa (opcional)
                    </label>
                    <textarea
                      rows={3}
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="Conte um pouco sobre sua empresa, se já tem logo ou fotos dos produtos..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2 space-y-3">
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                      <span>{loading ? 'Enviando...' : 'SOLICITAR ORÇAMENTO AGORA'}</span>
                    </button>

                    <a
                      href={createWhatsAppUrl(getWhatsAppDirectMsg())}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2.5 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-emerald-400 font-semibold text-xs transition-all flex items-center justify-center gap-2"
                    >
                      <MessageCircle className="w-4 h-4 text-emerald-400" />
                      <span>Ou envie direto pelo WhatsApp</span>
                    </a>
                  </div>

                  <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 pt-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                    <span>Seus dados são 100% confidenciais e usados apenas para contato comercial.</span>
                  </div>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
