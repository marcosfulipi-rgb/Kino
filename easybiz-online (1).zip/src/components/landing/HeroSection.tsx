import React from 'react';
import { createWhatsAppUrl } from '../../data/agencyData';
import { 
  ArrowRight, MessageCircle, FileText, CheckCircle2, 
  MapPin, Sparkles, ShieldCheck, Laptop 
} from 'lucide-react';

interface HeroSectionProps {
  onOpenQuoteModal: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenQuoteModal,
  onNavigateSection
}) => {
  return (
    <section id="hero" className="relative overflow-hidden bg-slate-950 text-white pt-14 pb-20 sm:pt-20 sm:pb-28 border-b border-slate-800">
      
      {/* Background architectural glow & grid */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_-20%,rgba(37,99,235,0.25),rgba(255,255,255,0))]" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_20%,#000_70%,transparent_100%)] opacity-35" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headline and Strategic Propositions */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Target Audience Badge */}
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-300 bg-blue-950/80 border border-blue-800/80 px-3.5 py-1.5 rounded-full shadow-sm">
              <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>Para Empresários de Curitiba, Região Metropolitana e Todo o Brasil</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1] font-display text-balance">
              Sua empresa merece <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-200">estar na internet!</span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
              Criamos sites profissionais para empresas que querem conquistar mais clientes, fortalecer sua marca e ter presença digital na internet.
            </p>

            {/* Differential Highlight Card */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800/90 shadow-lg flex items-start gap-3.5 max-w-xl">
              <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 mt-0.5 border border-blue-500/30">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
                  Nosso Diferencial Exclusivo
                </span>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                  <strong>Você não precisa entender de tecnologia ou programação.</strong> Nós desenvolvemos seu site e entregamos pronto para você apresentar sua empresa na internet.
                </p>
              </div>
            </div>

            {/* 3 Main Action Buttons with WhatsApp Integration */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 flex-wrap">
              
              {/* Botão 1: QUERO MEU SITE */}
              <button
                onClick={() => onNavigateSection('planos')}
                className="px-6 py-3.5 text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-lg hover:shadow-blue-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>QUERO MEU SITE</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Botão 2: SOLICITAR ORÇAMENTO */}
              <button
                onClick={onOpenQuoteModal}
                className="px-5 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <FileText className="w-4 h-4 text-blue-400" />
                <span>SOLICITAR ORÇAMENTO</span>
              </button>

              {/* Botão 3: FALAR PELO WHATSAPP */}
              <a
                href={createWhatsAppUrl('Olá! Quero falar pelo WhatsApp sobre a criação de um site profissional para o meu negócio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-3.5 text-sm font-semibold text-emerald-300 hover:text-white bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-700/60 rounded-xl transition-all flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>FALAR PELO WHATSAPP</span>
              </a>

            </div>

            {/* Proof highlights */}
            <div className="pt-4 flex items-center gap-6 text-xs text-slate-400 flex-wrap">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Sites a partir de R$ 300,00</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Entrega rápida e descomplicada</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Suporte direto em português</span>
              </div>
            </div>

          </div>

          {/* Right Column: High-End Multi-Device Showcase Visual */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-slate-800 bg-slate-900 aspect-16/10 group">
              <img
                src="/src/assets/images/agency_portfolio_showcase_1793637391253.jpg"
                alt="Showcase de sites profissionais responsivos para empresas"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent" />

              {/* Floating Badge 1: 100% Responsivo */}
              <div className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur-md rounded-xl p-3 shadow-lg border border-slate-700/80 text-xs space-y-1">
                <div className="flex items-center gap-1.5 text-blue-400 font-semibold">
                  <Laptop className="w-3.5 h-3.5" />
                  <span>100% Responsivo</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  Funciona perfeitamente em celulares, tablets e computadores.
                </p>
              </div>

              {/* Floating Badge 2: Pronto para Publicar */}
              <div className="absolute bottom-4 right-4 bg-slate-900/90 backdrop-blur-md rounded-xl p-3 shadow-lg border border-slate-700/80 text-xs text-white space-y-0.5">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Entrega Chave na Mão</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  Seu site pronto para receber visitas e orçamentos.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Feature summary strip */}
        <div className="mt-16 pt-10 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-6 text-left">
          <div>
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono-numbers block">
              100%
            </span>
            <span className="text-xs text-slate-400">Sem necessidade de saber programação</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-extrabold text-blue-400 font-mono-numbers block">
              R$ 300
            </span>
            <span className="text-xs text-slate-400">Pacotes acessíveis a partir de trezentos reais</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono-numbers block">
              3 a 5 dias
            </span>
            <span className="text-xs text-slate-400">Prazos de entrega ágeis para seu negócio</span>
          </div>
          <div>
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono-numbers block">
              WhatsApp
            </span>
            <span className="text-xs text-slate-400">Integração direta com o seu número</span>
          </div>
        </div>

      </div>
    </section>
  );
};
