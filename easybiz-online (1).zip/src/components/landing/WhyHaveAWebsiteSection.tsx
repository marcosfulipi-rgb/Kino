import React from 'react';
import { WHY_HAVE_A_WEBSITE, createWhatsAppUrl } from '../../data/agencyData';
import { 
  Clock, ShieldCheck, Layout, MapPin, PhoneCall, 
  ArrowRight, MessageCircle, CheckCircle2 
} from 'lucide-react';

interface WhyHaveAWebsiteSectionProps {
  onOpenQuoteModal: () => void;
}

export const WhyHaveAWebsiteSection: React.FC<WhyHaveAWebsiteSectionProps> = ({
  onOpenQuoteModal
}) => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Clock': return <Clock className="w-6 h-6 text-blue-600" />;
      case 'ShieldCheck': return <ShieldCheck className="w-6 h-6 text-blue-600" />;
      case 'Layout': return <Layout className="w-6 h-6 text-blue-600" />;
      case 'MapPin': return <MapPin className="w-6 h-6 text-blue-600" />;
      case 'PhoneCall': return <PhoneCall className="w-6 h-6 text-blue-600" />;
      default: return <CheckCircle2 className="w-6 h-6 text-blue-600" />;
    }
  };

  return (
    <section id="por-que-ter-um-site" className="py-20 sm:py-28 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <span className="text-xs font-semibold text-blue-600 uppercase tracking-wider">
            Presença Digital Essencial
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 font-display">
            Por Que Ter um Site Profissional?
          </h2>
          <p className="text-base text-slate-600 leading-relaxed">
            Seus futuros clientes já estão pesquisando pelo que você faz. Um site profissional garante que sua empresa seja encontrada com a credibilidade e seriedade que você construiu.
          </p>
        </div>

        {/* 5 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">
          
          {WHY_HAVE_A_WEBSITE.map((item, index) => (
            <div
              key={item.id}
              className={`p-8 rounded-2xl border transition-all flex flex-col justify-between space-y-5 bg-slate-50/60 hover:bg-white hover:shadow-md ${
                index === 0 ? 'md:col-span-2 lg:col-span-1 border-blue-200 bg-blue-50/30' : 'border-slate-200'
              }`}
            >
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                  {getIcon(item.iconName)}
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                    Vantagem 0{index + 1}
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 font-display">
                    {item.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              <div className="pt-2 text-xs font-semibold text-blue-600 flex items-center gap-1">
                <span>Destaque para sua empresa</span>
                <CheckCircle2 className="w-3.5 h-3.5" />
              </div>
            </div>
          ))}

          {/* 6th Card: Direct Call to Action */}
          <div className="p-8 rounded-2xl border border-blue-600 bg-gradient-to-br from-slate-900 to-blue-950 text-white shadow-xl flex flex-col justify-between space-y-6">
            <div className="space-y-3">
              <span className="text-xs uppercase font-mono tracking-wider text-blue-300">
                Transforme Visitas em Vendas
              </span>
              <h3 className="text-xl font-bold font-display text-white">
                Não perca mais clientes para a concorrência
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Empresas com site transmitem muito mais segurança na hora do fechamento. Dê esse passo agora mesmo com pacotes a partir de R$ 300,00.
              </p>
            </div>

            <div className="space-y-2.5">
              <button
                onClick={onOpenQuoteModal}
                className="w-full py-3 px-4 text-xs font-bold text-slate-950 bg-white hover:bg-slate-100 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>SOLICITAR ORÇAMENTO</span>
                <ArrowRight className="w-3.5 h-3.5 text-blue-600" />
              </button>

              <a
                href={createWhatsAppUrl('Olá! Gostaria de conversar pelo WhatsApp sobre os benefícios de um site para a minha empresa.')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 text-xs font-semibold text-emerald-300 hover:text-white bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-800/80 rounded-xl transition-all flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>FALAR PELO WHATSAPP</span>
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
