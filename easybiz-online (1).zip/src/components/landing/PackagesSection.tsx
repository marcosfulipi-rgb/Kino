import React, { useState } from 'react';
import { AGENCY_PACKAGES, createWhatsAppUrl } from '../../data/agencyData';
import { formatBRL } from '../../services/agencyStorage';
import { 
  Check, ArrowRight, MessageCircle, Sparkles, 
  ShieldCheck, HelpCircle, FileText, CheckCircle2 
} from 'lucide-react';

interface PackagesSectionProps {
  onOpenQuoteModal: (packageId?: string) => void;
}

export const PackagesSection: React.FC<PackagesSectionProps> = ({ onOpenQuoteModal }) => {
  const [selectedPlan, setSelectedPlan] = useState<string>('profissional');

  return (
    <section id="pacotes" className="py-20 sm:py-28 bg-slate-900 text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-900/60 border border-blue-700/60 text-blue-300 text-xs font-semibold uppercase tracking-wider">
            <span>Investimento Transparente & Justo</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display text-balance">
            Pacotes e Preços
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Escolha o plano ideal para a sua empresa. Sem mensalidades abusivas ou surpresas no final do projeto.
          </p>
        </div>

        {/* 3 Packages Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch mb-16">
          {AGENCY_PACKAGES.map((pkg) => {
            const isHighlighted = pkg.highlighted;
            return (
              <div
                key={pkg.id}
                className={`relative rounded-3xl p-8 flex flex-col justify-between transition-all duration-300 ${
                  isHighlighted
                    ? 'bg-gradient-to-b from-slate-800 to-slate-950 border-2 border-blue-500 shadow-2xl shadow-blue-500/20 scale-100 lg:-translate-y-2'
                    : 'bg-slate-950/80 border border-slate-800 hover:border-slate-700 shadow-xl'
                }`}
              >
                {/* Badge if highlighted */}
                {isHighlighted && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[11px] font-bold uppercase tracking-wider py-1 px-4 rounded-full shadow-md flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{pkg.badge || 'Mais Escolhido por Empresários'}</span>
                  </div>
                )}

                <div>
                  {/* Title & Tagline */}
                  <div className="space-y-2 border-b border-slate-800 pb-6">
                    <h3 className="text-2xl font-extrabold text-white font-display">
                      {pkg.name}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {pkg.tagline}
                    </p>
                  </div>

                  {/* Price */}
                  <div className="py-6 border-b border-slate-800">
                    <span className="text-xs uppercase font-semibold text-slate-400 block mb-1">
                      Investimento Único
                    </span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-4xl sm:text-5xl font-black text-white tracking-tight">
                        {formatBRL(pkg.priceBRL)}
                      </span>
                    </div>
                    <span className="text-[11px] text-blue-400 block mt-2 font-medium">
                      {pkg.deliveryTime}
                    </span>
                  </div>

                  {/* Target Audience Note */}
                  <div className="py-4 text-xs text-slate-300 bg-slate-900/60 rounded-xl px-3.5 my-5 border border-slate-800/80">
                    <strong className="text-slate-200">Recomendado:</strong> {pkg.targetAudience}
                  </div>

                  {/* Feature List */}
                  <div className="space-y-3 pb-6">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                      O que está incluso:
                    </span>
                    {pkg.features.map((feature, fIndex) => (
                      <div key={fIndex} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                        <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                        <span className="leading-snug">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Main Action Buttons */}
                <div className="space-y-2.5 pt-6 border-t border-slate-800">
                  <button
                    onClick={() => onOpenQuoteModal(pkg.id)}
                    className={`w-full py-3.5 px-4 rounded-xl font-bold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isHighlighted
                        ? 'bg-blue-600 hover:bg-blue-700 text-white'
                        : 'bg-white hover:bg-slate-100 text-slate-900'
                    }`}
                  >
                    <span>QUERO MEU SITE</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onOpenQuoteModal(pkg.id)}
                    className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-blue-400" />
                    <span>SOLICITAR ORÇAMENTO</span>
                  </button>

                  <a
                    href={createWhatsAppUrl(`Olá! Tenho interesse no pacote *${pkg.name}* (R$ ${pkg.priceBRL},00). Gostaria de tirar dúvidas e dar início ao projeto.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 font-semibold text-xs transition-all flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>FALAR PELO WHATSAPP</span>
                  </a>
                </div>

              </div>
            );
          })}
        </div>

        {/* Commercial Clarifications & Guarantees */}
        <div className="rounded-2xl bg-slate-950 border border-slate-800 p-6 sm:p-8 grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Aprovação Garantida</h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Você só autoriza a publicação quando estiver 100% satisfeito com o visual e os textos.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Suporte Direto no WhatsApp</h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Atendimento humanizado para empresários de Curitiba, Paraná e todo o território nacional.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center shrink-0 border border-purple-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Sem Complicações Técnicas</h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Nós configuramos tudo e entregamos pronto para você divulgar para seus clientes.
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
