import React, { useState } from 'react';
import { AGENCY_SERVICES, createWhatsAppUrl } from '../../data/agencyData';
import { AgencyService } from '../../types';
import { 
  Building2, TrendingUp, ShoppingBag, Briefcase, 
  Utensils, Scissors, HardHat, Sparkles, 
  ArrowRight, MessageCircle, CheckCircle2, ChevronRight, Eye
} from 'lucide-react';

interface ServicesSectionProps {
  onOpenQuoteModal: (packageId?: string, serviceId?: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenQuoteModal }) => {
  const [activeTab, setActiveTab] = useState<string>(AGENCY_SERVICES[0].id);

  const activeService = AGENCY_SERVICES.find(s => s.id === activeTab) || AGENCY_SERVICES[0];

  const getServiceIcon = (iconName: string, className = "w-6 h-6") => {
    switch (iconName) {
      case 'Building2': return <Building2 className={className} />;
      case 'TrendingUp': return <TrendingUp className={className} />;
      case 'ShoppingBag': return <ShoppingBag className={className} />;
      case 'Briefcase': return <Briefcase className={className} />;
      case 'Utensils': return <Utensils className={className} />;
      case 'Scissors': return <Scissors className={className} />;
      case 'HardHat': return <HardHat className={className} />;
      case 'Sparkles': return <Sparkles className={className} />;
      default: return <Sparkles className={className} />;
    }
  };

  return (
    <section id="servicos" className="py-20 sm:py-28 bg-slate-900 text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-900/60 border border-blue-700/60 text-blue-300 text-xs font-semibold uppercase tracking-wider">
            <span>Soluções Sob Medida</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display text-balance">
            Serviços Especializados de Criação de Sites
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Desenvolvemos a presença online ideal para cada tipo de negócio, respeitando as características do seu público e focando em gerar contatos e vendas.
          </p>
        </div>

        {/* 8 Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {AGENCY_SERVICES.map((service, index) => {
            const isSelected = service.id === activeTab;
            return (
              <div
                key={service.id}
                onClick={() => setActiveTab(service.id)}
                className={`group relative rounded-2xl p-6 transition-all duration-200 cursor-pointer flex flex-col justify-between border ${
                  isSelected 
                    ? 'bg-slate-800/90 border-blue-500 shadow-xl shadow-blue-500/10 ring-2 ring-blue-500/30' 
                    : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800/50 hover:border-slate-700'
                }`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                      isSelected 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-slate-800 text-blue-400 group-hover:bg-blue-600 group-hover:text-white'
                    }`}>
                      {getServiceIcon(service.iconName)}
                    </div>
                    <span className="text-xs font-mono font-bold text-slate-400">
                      0{index + 1}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-blue-300 transition-colors">
                      {service.title.replace(/^\d+\.\s*/, '')}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                      {service.shortDescription}
                    </p>
                  </div>
                </div>

                <div className="pt-6 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold">
                  <span className={isSelected ? 'text-blue-400' : 'text-slate-400 group-hover:text-slate-200'}>
                    {isSelected ? 'Em exibição' : 'Ver detalhes'}
                  </span>
                  <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'translate-x-1 text-blue-400' : 'text-slate-500 group-hover:translate-x-1'}`} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Service Detailed Spotlight */}
        <div className="bg-slate-950 rounded-3xl border border-slate-800 p-6 sm:p-10 shadow-2xl overflow-hidden relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-blue-600/20 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
                {getServiceIcon(activeService.iconName, 'w-4 h-4')}
                <span>Segmento em Destaque</span>
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                  {activeService.title}
                </h3>
                <p className="text-sm sm:text-base text-slate-300 mt-3 leading-relaxed">
                  {activeService.fullDescription}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  Recomendado para:
                </span>
                <p className="text-sm font-semibold text-slate-200">
                  {activeService.idealFor}
                </p>
              </div>

              {/* What's included */}
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-3">
                  Recursos essenciais inclusos neste modelo:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {activeService.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 text-xs sm:text-sm text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons for this segment */}
              <div className="pt-4 flex flex-wrap gap-3">
                <button
                  onClick={() => onOpenQuoteModal(undefined, activeService.id)}
                  className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span>QUERO MEU SITE DESTE SEGMENTO</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href={createWhatsAppUrl(`Olá! Tenho interesse na criação de um site para o segmento: ${activeService.title}. Como podemos iniciar?`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>FALAR PELO WHATSAPP</span>
                </a>
              </div>
            </div>

            {/* Right Mockup Graphic */}
            <div className="lg:col-span-5">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-3 shadow-2xl relative">
                <div className="flex items-center gap-2 pb-2.5 px-2 border-b border-slate-800 text-xs text-slate-400">
                  <div className="flex gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/80"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
                  </div>
                  <span className="font-mono text-[10px] text-slate-300 ml-auto bg-slate-950 px-2.5 py-0.5 rounded border border-slate-800">
                    exemplo-modelo-{activeService.id}.com.br
                  </span>
                </div>

                <div className="mt-3 aspect-4/3 rounded-xl overflow-hidden relative group">
                  <img
                    src={activeService.sampleMockupImage || '/src/assets/images/agency_portfolio_showcase_1793637391253.jpg'}
                    alt={activeService.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent flex flex-col justify-end p-5">
                    <span className="text-[11px] font-mono text-blue-300 uppercase tracking-wider">
                      Modelo Americano Responsivo
                    </span>
                    <h4 className="text-base font-bold text-white mt-1">
                      Visual moderno, rápido e com alta taxa de conversão
                    </h4>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
