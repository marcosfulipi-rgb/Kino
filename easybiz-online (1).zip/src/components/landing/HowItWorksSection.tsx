import React from 'react';
import { HOW_IT_WORKS_STEPS, createWhatsAppUrl } from '../../data/agencyData';
import { 
  MessageSquare, Users, Laptop, CheckCircle, 
  Rocket, ArrowRight, MessageCircle 
} from 'lucide-react';

interface HowItWorksSectionProps {
  onOpenQuoteModal: () => void;
}

export const HowItWorksSection: React.FC<HowItWorksSectionProps> = ({ onOpenQuoteModal }) => {
  const getStepIcon = (index: number) => {
    switch (index) {
      case 0: return <MessageSquare className="w-5 h-5" />;
      case 1: return <Users className="w-5 h-5" />;
      case 2: return <Laptop className="w-5 h-5" />;
      case 3: return <CheckCircle className="w-5 h-5" />;
      case 4: return <Rocket className="w-5 h-5" />;
      default: return <CheckCircle className="w-5 h-5" />;
    }
  };

  return (
    <section id="como-funciona" className="py-20 sm:py-28 bg-slate-950 text-white relative border-y border-slate-800">
      
      {/* Background subtleties */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(37,99,235,0.1),transparent_70%)]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-950 border border-blue-800 text-blue-400 text-xs font-semibold uppercase tracking-wider">
            <span>Passo a Passo Simples</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display text-balance">
            Como Funciona?
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Você não precisa se preocupar com programação, servidores ou termos complicados. Nós cuidamos de tudo do início ao fim.
          </p>
        </div>

        {/* 5 Steps Linear Flow */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-16">
          {HOW_IT_WORKS_STEPS.map((step, idx) => (
            <div 
              key={step.stepNumber}
              className="relative rounded-2xl bg-slate-900/90 border border-slate-800 p-6 flex flex-col justify-between hover:border-blue-500/60 transition-all group"
            >
              {/* Connector line on larger screens */}
              {idx < HOW_IT_WORKS_STEPS.length - 1 && (
                <div className="hidden lg:block absolute -right-3.5 top-1/2 -translate-y-1/2 z-10 w-7 h-0.5 bg-blue-600/40" />
              )}

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    {getStepIcon(idx)}
                  </div>
                  <span className="font-mono text-2xl font-black text-slate-700 group-hover:text-blue-400/80 transition-colors">
                    {step.stepNumber}
                  </span>
                </div>

                <div className="space-y-2">
                  <h3 className="text-base font-bold text-white group-hover:text-blue-300 transition-colors leading-snug">
                    {step.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>

              <div className="mt-6 pt-3 border-t border-slate-800/60 flex items-center gap-1.5 text-[11px] font-semibold text-blue-400">
                <span>Etapa {idx + 1} de 5</span>
              </div>
            </div>
          ))}
        </div>

        {/* Reassurance Banner */}
        <div className="rounded-2xl bg-gradient-to-r from-blue-900/60 via-slate-900 to-blue-950/60 border border-blue-800/60 p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-lg font-bold text-white">
              Pronto para colocar seu negócio na internet com rapidez?
            </h4>
            <p className="text-xs sm:text-sm text-slate-300">
              Inicie a conversa agora mesmo com nossa equipe e receba sua proposta sem compromisso.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={onOpenQuoteModal}
              className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>SOLICITAR ORÇAMENTO</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              href={createWhatsAppUrl('Olá! Gostaria de saber como funciona a criação de sites e solicitar um orçamento para minha empresa.')}
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>FALAR PELO WHATSAPP</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
