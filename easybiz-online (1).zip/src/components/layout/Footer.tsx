import React from 'react';
import { COMMERCIAL_INFO, createWhatsAppUrl } from '../../data/agencyData';
import { MessageCircle, MapPin, Phone, Mail, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  onNavigateSection: (sectionId: string) => void;
  onOpenQuoteModal: (packageId?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateSection, onOpenQuoteModal }) => {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          
          {/* Brand & Mission */}
          <div className="md:col-span-1 space-y-4">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white text-base font-extrabold shadow-sm">
                E
              </span>
              <span className="text-xl font-bold tracking-tight text-white font-display">
                EasyBiz<span className="text-blue-400">.online</span>
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Especialistas na criação de sites profissionais para empresários, comerciantes, profissionais autônomos e pequenas e médias empresas.
            </p>
            <div className="text-xs text-blue-400 font-medium pt-1 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" />
              <span>Curitiba - PR · Atendimento em Todo o Brasil</span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Navegação
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-slate-400">
              <li>
                <button 
                  onClick={() => onNavigateSection('servicos')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Serviços de Criação de Sites
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateSection('por-que-ter-um-site')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Por Que Ter um Site?
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateSection('como-funciona')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Como Funciona o Processo?
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateSection('pacotes')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Pacotes e Preços
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateSection('contato')} 
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Fale Conosco
                </button>
              </li>
            </ul>
          </div>

          {/* Packages */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Pacotes Disponíveis
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-slate-400">
              <li>
                <button 
                  onClick={() => onOpenQuoteModal('essencial')} 
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Site Essencial — R$ 300,00
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onOpenQuoteModal('profissional')} 
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Site Profissional — R$ 450,00
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onOpenQuoteModal('premium')} 
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Site Premium — R$ 600,00
                </button>
              </li>
              <li className="pt-2">
                <button
                  onClick={() => onOpenQuoteModal()}
                  className="text-xs text-blue-400 font-semibold hover:text-blue-300 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span>Solicitar Orçamento Personalizado</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </li>
            </ul>
          </div>

          {/* Direct Commercial Contact */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-200 mb-4">
              Atendimento Comercial
            </h4>
            <div className="space-y-3 text-xs sm:text-sm text-slate-400">
              <a
                href={createWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-emerald-400 hover:text-emerald-300 font-bold transition-colors"
              >
                <MessageCircle className="w-4 h-4 shrink-0" />
                <span>WhatsApp: {COMMERCIAL_INFO.whatsappDisplay}</span>
              </a>

              <a 
                href={`tel:${COMMERCIAL_INFO.whatsappNumber}`} 
                className="flex items-center gap-2 hover:text-white transition-colors"
              >
                <Phone className="w-4 h-4 text-blue-400 shrink-0" />
                <span>{COMMERCIAL_INFO.phone}</span>
              </a>

              <a 
                href={`mailto:${COMMERCIAL_INFO.email}`} 
                className="flex items-center gap-2 hover:text-white transition-colors truncate"
              >
                <Mail className="w-4 h-4 text-blue-400 shrink-0" />
                <span className="truncate">{COMMERCIAL_INFO.email}</span>
              </a>

              <div className="pt-1 text-xs text-slate-400">
                {COMMERCIAL_INFO.address}<br />
                {COMMERCIAL_INFO.city} - {COMMERCIAL_INFO.state}
              </div>
            </div>
          </div>

        </div>

        {/* Project Export Bar for Lovable & Netlify */}
        <div className="mt-12 p-5 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <h5 className="text-sm font-bold text-white flex items-center justify-center md:justify-start gap-2">
              <span>Exportar Projeto para Hospedagem</span>
              <span className="text-[10px] font-mono uppercase bg-blue-900/80 text-blue-300 px-2 py-0.5 rounded-full border border-blue-700/60">
                Lovable & Netlify
              </span>
            </h5>
            <p className="text-xs text-slate-400">
              Baixe os arquivos do projeto em arquivo .ZIP prontos para rodar ou hospedar imediatamente.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2.5">
            <a
              href="/easybiz-online.zip"
              download="easybiz-online-codigo-fonte.zip"
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md transition-all flex items-center gap-2"
              title="Baixar código fonte completo com React, Tailwind e componentes"
            >
              <span>Baixar Código Fonte (.ZIP)</span>
            </a>

            <a
              href="/easybiz-dist.zip"
              download="easybiz-dist-netlify.zip"
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition-all flex items-center gap-2"
              title="Baixar site pronto para arrastar direto no Netlify Drop"
            >
              <span>Baixar Site Pronto (.ZIP Netlify)</span>
            </a>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} EasyBiz Online · Criação de Sites Profissionais. Todos os direitos reservados.</p>
          <div className="flex items-center gap-4">
            <span className="hover:text-slate-300">Curitiba & Região Metropolitana</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-slate-300">Padrão Americano de Design</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-slate-300">100% Responsivo</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
