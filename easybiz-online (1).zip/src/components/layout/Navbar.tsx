import React, { useState } from 'react';
import { COMMERCIAL_INFO, createWhatsAppUrl } from '../../data/agencyData';
import { MessageCircle, ArrowRight, Menu, X, Globe } from 'lucide-react';

interface NavbarProps {
  onOpenQuoteModal: (packageId?: string) => void;
  onNavigateSection: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenQuoteModal,
  onNavigateSection
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (sectionId: string) => {
    onNavigateSection(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-900/95 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6 px-4 sm:px-6 lg:px-8 h-18">
        
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => handleNavClick('hero')}
          className="flex items-center gap-2.5 text-left text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 hover:opacity-95 transition-opacity cursor-pointer"
        >
          <span className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white text-base font-extrabold shadow-sm">
            E
          </span>
          <div className="flex flex-col">
            <span className="font-display leading-none text-lg">
              EasyBiz<span className="text-blue-400">.online</span>
            </span>
            <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 mt-0.5">
              Criação de Sites Profissionais
            </span>
          </div>
        </button>

        {/* Zone 2: 4-5 clean single-line navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
          <button
            onClick={() => handleNavClick('servicos')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Serviços
          </button>
          <button
            onClick={() => handleNavClick('por-que-ter-um-site')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Por Que Ter um Site?
          </button>
          <button
            onClick={() => handleNavClick('como-funciona')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Como Funciona?
          </button>
          <button
            onClick={() => handleNavClick('pacotes')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Pacotes e Preços
          </button>
          <button
            onClick={() => handleNavClick('contato')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Contato
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          <a
            href={createWhatsAppUrl('Olá! Quero falar com um especialista sobre a criação de um site para a minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-emerald-400 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/60 rounded-xl transition-all whitespace-nowrap shrink-0"
          >
            <MessageCircle className="w-4 h-4 text-emerald-400" />
            <span>FALAR PELO WHATSAPP</span>
          </a>

          <button
            onClick={() => onOpenQuoteModal()}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-md transition-all whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>QUERO MEU SITE</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex sm:hidden items-center gap-2">
          <a
            href={createWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 text-emerald-400 bg-emerald-950/80 rounded-lg border border-emerald-800/80"
            title="WhatsApp"
          >
            <MessageCircle className="w-4 h-4" />
          </a>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-300 hover:text-white rounded-lg bg-slate-800"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 border-b border-slate-800 px-4 py-5 space-y-3">
          <button
            onClick={() => handleNavClick('servicos')}
            className="block w-full text-left py-2 text-sm text-slate-300 hover:text-white"
          >
            Serviços
          </button>
          <button
            onClick={() => handleNavClick('por-que-ter-um-site')}
            className="block w-full text-left py-2 text-sm text-slate-300 hover:text-white"
          >
            Por Que Ter um Site?
          </button>
          <button
            onClick={() => handleNavClick('como-funciona')}
            className="block w-full text-left py-2 text-sm text-slate-300 hover:text-white"
          >
            Como Funciona?
          </button>
          <button
            onClick={() => handleNavClick('pacotes')}
            className="block w-full text-left py-2 text-sm text-slate-300 hover:text-white"
          >
            Pacotes e Preços
          </button>
          <button
            onClick={() => handleNavClick('contato')}
            className="block w-full text-left py-2 text-sm text-slate-300 hover:text-white"
          >
            Contato
          </button>

          <div className="pt-3 border-t border-slate-800 space-y-2">
            <button
              onClick={() => {
                onOpenQuoteModal();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 text-xs font-semibold text-white bg-blue-600 rounded-xl text-center"
            >
              QUERO MEU SITE
            </button>
            <a
              href={createWhatsAppUrl('Olá! Quero tirar dúvidas sobre a criação de sites pelo WhatsApp.')}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 text-xs font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800 rounded-xl text-center"
            >
              <MessageCircle className="w-4 h-4" />
              <span>FALAR PELO WHATSAPP</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
