import React, { useState, useEffect } from 'react';
import { AGENCY_PACKAGES, AGENCY_SERVICES, createWhatsAppUrl } from '../../data/agencyData';
import { saveInquiry } from '../../services/agencyStorage';
import { X, Send, MessageCircle, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';

interface QuoteRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPackageId?: string;
  selectedServiceId?: string;
}

export const QuoteRequestModal: React.FC<QuoteRequestModalProps> = ({
  isOpen,
  onClose,
  selectedPackageId,
  selectedServiceId
}) => {
  const [formData, setFormData] = useState({
    name: '',
    companyName: '',
    whatsapp: '',
    city: 'Curitiba',
    state: 'PR',
    packageTier: selectedPackageId || 'profissional',
    serviceCategory: selectedServiceId || 'institucional',
    notes: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (selectedPackageId) {
      setFormData(prev => ({ ...prev, packageTier: selectedPackageId }));
    }
    if (selectedServiceId) {
      setFormData(prev => ({ ...prev, serviceCategory: selectedServiceId }));
    }
  }, [selectedPackageId, selectedServiceId]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.whatsapp) return;

    setLoading(true);
    setTimeout(() => {
      saveInquiry({
        name: formData.name,
        companyName: formData.companyName,
        whatsapp: formData.whatsapp,
        city: formData.city,
        state: formData.state,
        packageTier: formData.packageTier,
        serviceCategory: formData.serviceCategory,
        notes: formData.notes
      });
      setLoading(false);
      setSubmitted(true);
    }, 350);
  };

  const getPackageName = (id: string) => {
    const pkg = AGENCY_PACKAGES.find(p => p.id === id);
    return pkg ? `${pkg.name} (R$ ${pkg.priceBRL},00)` : id;
  };

  const getWhatsAppMsg = () => {
    const pkg = AGENCY_PACKAGES.find(p => p.id === formData.packageTier);
    const srv = AGENCY_SERVICES.find(s => s.id === formData.serviceCategory);
    return `Olá! Meu nome é ${formData.name || 'Empresário'} da empresa ${formData.companyName || '(a definir)'} em ${formData.city}/${formData.state}. Quero solicitar meu site pelo pacote *${pkg?.name || 'Profissional'}* para o segmento *${srv?.title || 'Institucional'}*.`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-xl rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-2xl p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {submitted ? (
          <div className="py-8 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold font-display text-white">
                Solicitação Enviada!
              </h3>
              <p className="text-sm text-slate-300 max-w-sm mx-auto">
                Recebemos sua solicitação. Nosso consultor entrará em contato direto pelo seu WhatsApp para dar início ao seu novo site.
              </p>
            </div>

            <div className="pt-2 flex flex-col gap-3">
              <a
                href={createWhatsAppUrl(getWhatsAppMsg())}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>AGILIZAR NO WHATSAPP AGORA</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  setSubmitted(false);
                  onClose();
                }}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-blue-400">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Proposta Comercial Expressa</span>
              </div>
              <h3 className="text-2xl font-bold font-display text-white">
                Solicitar Meu Site Profissional
              </h3>
              <p className="text-xs text-slate-400">
                Preencha os dados abaixo ou fale direto com um especialista no WhatsApp.
              </p>
            </div>

            {/* Select Package & Service */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">
                  Pacote Escolhido
                </label>
                <select
                  value={formData.packageTier}
                  onChange={(e) => setFormData({ ...formData, packageTier: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs sm:text-sm focus:outline-none focus:border-blue-500"
                >
                  {AGENCY_PACKAGES.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} — R$ {p.priceBRL},00
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">
                  Segmento da Sua Empresa
                </label>
                <select
                  value={formData.serviceCategory}
                  onChange={(e) => setFormData({ ...formData, serviceCategory: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs sm:text-sm focus:outline-none focus:border-blue-500"
                >
                  {AGENCY_SERVICES.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.title}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Name & Business Name */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">
                  Seu Nome *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Seu nome"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">
                  Nome da Empresa
                </label>
                <input
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                  placeholder="Nome do seu negócio"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* WhatsApp & City */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">
                  WhatsApp com DDD *
                </label>
                <input
                  type="tel"
                  required
                  value={formData.whatsapp}
                  onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                  placeholder="(41) 99999-9999"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">
                  Cidade / Estado
                </label>
                <input
                  type="text"
                  value={`${formData.city} - ${formData.state}`}
                  onChange={(e) => {
                    const parts = e.target.value.split('-');
                    setFormData({
                      ...formData,
                      city: parts[0]?.trim() || '',
                      state: parts[1]?.trim() || ''
                    });
                  }}
                  placeholder="Curitiba - PR"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* Notes */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">
                Observações ou Dúvidas
              </label>
              <textarea
                rows={2}
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Ex: Gostaria de incluir botão para cardápio e mapa de localização..."
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            {/* Buttons */}
            <div className="space-y-2.5 pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{loading ? 'Processando...' : 'QUERO MEU SITE — ENVIAR PROPOSTA'}</span>
              </button>

              <a
                href={createWhatsAppUrl(getWhatsAppMsg())}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 font-semibold text-xs transition-all flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>OU FALAR PELO WHATSAPP AGORA</span>
              </a>
            </div>

            <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              <span>Sem custos adiantados até a confirmação do projeto.</span>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
