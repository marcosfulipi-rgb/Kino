import React, { useState } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HeroSection } from './components/landing/HeroSection';
import { WhyHaveAWebsiteSection } from './components/landing/WhyHaveAWebsiteSection';
import { ServicesSection } from './components/landing/ServicesSection';
import { HowItWorksSection } from './components/landing/HowItWorksSection';
import { PackagesSection } from './components/landing/PackagesSection';
import { ContactSection } from './components/landing/ContactSection';
import { QuoteRequestModal } from './components/modals/QuoteRequestModal';
import { createWhatsAppUrl } from './data/agencyData';
import { MessageCircle } from 'lucide-react';

export default function App() {
  const [quoteModalOpen, setQuoteModalOpen] = useState(false);
  const [selectedPackageId, setSelectedPackageId] = useState<string | undefined>('profissional');
  const [selectedServiceId, setSelectedServiceId] = useState<string | undefined>(undefined);

  const handleOpenQuoteModal = (packageId?: string, serviceId?: string) => {
    setSelectedPackageId(packageId || 'profissional');
    setSelectedServiceId(serviceId);
    setQuoteModalOpen(true);
  };

  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        onOpenQuoteModal={handleOpenQuoteModal}
        onNavigateSection={handleNavigateSection}
      />

      {/* Main Content Flow */}
      <main className="flex-1">
        {/* Hero Section */}
        <HeroSection
          onOpenQuoteModal={() => handleOpenQuoteModal()}
          onNavigateSection={handleNavigateSection}
        />

        {/* Por Que Ter um Site? Section */}
        <WhyHaveAWebsiteSection
          onOpenQuoteModal={() => handleOpenQuoteModal()}
        />

        {/* 8 Serviços Section */}
        <ServicesSection
          onOpenQuoteModal={handleOpenQuoteModal}
        />

        {/* Como Funciona? Section (5 Steps) */}
        <HowItWorksSection
          onOpenQuoteModal={() => handleOpenQuoteModal()}
        />

        {/* Pacotes e Preços (R$ 300, R$ 450, R$ 600) */}
        <PackagesSection
          onOpenQuoteModal={handleOpenQuoteModal}
        />

        {/* Contato Comercial & Formulário de Orçamento */}
        <ContactSection
          initialPackageId={selectedPackageId}
          initialServiceId={selectedServiceId}
        />
      </main>

      {/* Agency Footer */}
      <Footer
        onNavigateSection={handleNavigateSection}
        onOpenQuoteModal={handleOpenQuoteModal}
      />

      {/* Floating WhatsApp Action Button */}
      <a
        href={createWhatsAppUrl('Olá! Gostaria de tirar dúvidas sobre a criação de sites profissionais para minha empresa.')}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Falar pelo WhatsApp"
        className="fixed bottom-6 right-6 z-40 group flex items-center gap-3 bg-emerald-600 hover:bg-emerald-500 text-white p-3.5 sm:px-5 sm:py-3.5 rounded-full shadow-2xl shadow-emerald-950/60 transition-all duration-300 hover:scale-105 active:scale-95"
      >
        <MessageCircle className="w-6 h-6 animate-pulse" />
        <span className="hidden sm:inline font-bold text-xs uppercase tracking-wider">
          Falar pelo WhatsApp
        </span>
      </a>

      {/* Interactive Quote Request Modal */}
      <QuoteRequestModal
        isOpen={quoteModalOpen}
        onClose={() => setQuoteModalOpen(false)}
        selectedPackageId={selectedPackageId}
        selectedServiceId={selectedServiceId}
      />
    </div>
  );
}
